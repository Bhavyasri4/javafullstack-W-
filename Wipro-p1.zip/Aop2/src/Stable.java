


	import java.util.HashMap;
	import java.util.Map;

	public class Stable {

	    // Method to check if a number is stable
	    public static boolean isStable(int num) {
	        
	        String numStr = String.valueOf(num);

	       
	        Map<Character, Integer> digitFrequencyMap = new HashMap<>();

	        for (char digit : numStr.toCharArray()) {
	            digitFrequencyMap.put(digit, digitFrequencyMap.getOrDefault(digit, 0) + 1);
	        }

	        int frequency = digitFrequencyMap.get(numStr.charAt(0));


	        for (int freq : digitFrequencyMap.values()) {
	            if (freq != frequency) {
	                return false;
	            }
	        }

	        return true;
	    }

	    public static void main(String[] args) {
	        int num = 1221;
	        if (isStable(num)) {
	            System.out.println(num + " is a stable number.");
	        } else {
	            System.out.println(num + " is not a stable number.");
	        }

	        num = 1234;
	        if (isStable(num)) {
	            System.out.println(num + " is a stable number.");
	        } else {
	            System.out.println(num + " is not a stable number.");
	        }
	    }
	}