class A{
	A(){ System.out.println("A1 isno arg cons");}
	A(int a){ System.out.println("A1is cons");}
}
class B extends A{
	B(){ System.out.println("B1 is no arg");}
	B(int b){ 
		System.out.println("B1 is cons");}
}
class C extends B{
	C(){ System.out .println("C1 is no arg");}
	C(int c){ 
		System.out.println("C1 is cons");}
	
}

public class S3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C1  ca=new C1();
       
	}

}




