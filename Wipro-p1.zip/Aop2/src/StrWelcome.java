import java.util.*;
public class StrWelcome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String st=sc.nextLine();
		System.out.println("Welcome "+st);

	}

}
