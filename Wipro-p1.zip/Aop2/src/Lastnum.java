import java.util.Scanner;

public class Lastnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	    int num1=sc.nextInt();
	    Scanner sc1=new Scanner(System.in);
	    int num2=sc1.nextInt();   
	    int a=num1%10;
	    int b=num2%10;
	    if(a==b)
	    	System.out.println("Same");
	    else
	    	System.out.println("different");
	    

	}

}
