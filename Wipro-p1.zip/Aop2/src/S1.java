class A1{
	A1(){ System.out.println("A1 isno arg cons");}
	A1(int a){ System.out.println("A1is cons");}
}
class B1 extends A1{
	B1(){ System.out.println("B1 is no arg");}
	B1(int b){ super(1000);
		System.out.println("B1 is cons");}
}
class C1 extends B1{
	C1(){ System.out .println("C1 is no arg");}
	C1(int c){ 
		System.out.println("C1 is cons");}
	
}

public class S1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C1  ca=new C1(10);
       
	}

}
