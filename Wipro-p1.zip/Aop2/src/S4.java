import java.util.*;
public class S4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String first=sc.nextLine();
		String second=sc.nextLine();
		System.out.println(first +" Technology "+ second);

	}

}
