package Testingdemo;
import static org.junit.Assert.*;

import org.junit.Test;


public class TestCal {
	@Test
	public void testAdd()
	{
		Calculate c=new Calculate();
		int res=c.add(10,20);
		assertEquals(30,res);
	}
	@Test
	public void testSub()
	{
		Calculate c=new Calculate();
		int ress=c.sub(10,20);
		assertEquals(-10,ress);
	}

}
