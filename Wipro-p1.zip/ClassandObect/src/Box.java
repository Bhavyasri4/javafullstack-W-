import java.util.*;
public class Box {
	public  Box(int length,int width,int heigth)
	{
      volume();
	{
		return length*width*heigth;
	}
	}
	private void volume() {
		// TODO Auto-generated method stub
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int length=sc.nextInt();
		int width=sc.nextInt();
		int heigth=sc.nextInt();
		Box b1=new Box();
		System.out.println("voume",b1.volume);

	}

}
w