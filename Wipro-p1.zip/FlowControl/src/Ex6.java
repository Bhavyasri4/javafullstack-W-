import java.util.*;
public class Ex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  if (args.length != 2) {
	            System.out.println("Usage: java InterestRate <Gender> <Age>");
	            return;
	        }

	        String gender = args[0];
	        int age;

	        try {
	            age = Integer.parseInt(args[1]);
	        } catch (NumberFormatException e) {
	            System.out.println("Age must be an integer.");
	            return;
	        }

	        String interestRate = getInterestRate(gender, age);
	        System.out.println("The percentage of interest is " + interestRate);
	    }

	    public static String getInterestRate(String gender, int age) {
	        if ("Female".equalsIgnoreCase(gender)) {
	            if (age >= 1 && age <= 58) {
	                return "8.2%";
	            } else if (age >= 59 && age <= 100) {
	                return "9.2%";
	            }
	        } else if ("Male".equalsIgnoreCase(gender)) {
	            if (age >= 1 && age <= 58) {
	                return "8.4%";
	            } else if (age >= 59 && age <= 100) {
	                return "10.5%";
	            }
	        }
	        return "Invalid input";

	}

}
