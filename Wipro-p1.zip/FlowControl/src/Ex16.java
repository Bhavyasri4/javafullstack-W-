import java.util.*;
public class Ex16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		int a = sc.nextInt();
		int rem,sum=0;
		while(a!=0)
		{
			rem=a%10;
			System.out.print(rem);
			a=a/10;
		}

	}

}
