import java.util.*;
public class LastDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int first=sc.nextInt();
		int second=sc.nextInt();
		int a=first%10;
		int  b=second%10;
		if(a==b)
			System.out.println("True");
		else
			System.out.println("False");;

	}

}
