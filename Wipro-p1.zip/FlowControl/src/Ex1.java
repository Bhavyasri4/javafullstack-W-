import java.util.*;
public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner = new Scanner(System.in);
	        System.out.println("Enter an integer number: ");
	        int number = scanner.nextInt();

	        if (number > 0) {
	            System.out.println("The number is Positive.");
	        } else if (number < 0) {
	            System.out.println("The number is Negative.");
	        } else {
	            System.out.println("The number is Zero.");
	        }

	        System.out.println("Enter the first non-negative integer: ");
	        int firstNumber = scanner.nextInt();
	        System.out.println("Enter the second non-negative integer: ");
	        int secondNumber = scanner.nextInt();

	        if (lastDigit(firstNumber, secondNumber)) {
	            System.out.println("The two numbers have the same last digit.");
	        } else {
	            System.out.println("The two numbers do not have the same last digit.");
	        }

	        scanner.close();
	    }

	    public static boolean lastDigit(int a, int b) {
	        return (a % 10) == (b % 10);
	    }

	}


