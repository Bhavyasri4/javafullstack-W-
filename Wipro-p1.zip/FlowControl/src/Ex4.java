import java.util.*;
public class Ex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the letters you want to sort:");
			String input=sc.nextLine();
			char[] lettersArray=input.toCharArray();
			Arrays.sort(lettersArray);
			System.out.println("Input letters in alphabetical order:"+new String(lettersArray));
		}

	}

}
