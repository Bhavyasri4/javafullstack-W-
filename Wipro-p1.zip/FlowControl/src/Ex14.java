import java.util.*;
public class Ex14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter a number: ");
	        int number = scanner.nextInt();
	        int sum = 0;
	        number = Math.abs(number);
	        for (; number > 0; number /= 10) {
	            sum += number % 10;
	        }

	        System.out.println("Sum of the digits: " + sum);

	}

}
