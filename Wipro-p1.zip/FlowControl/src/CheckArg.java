
public class CheckArg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args.length==0)
			System.out.println("No Value");
		else
		{
			for(int i=0;i<args.length;i++)
			{
				if(i!=0)
					System.out.println(", ");
			
			System.out.println(args[i]);
			}
		}

	}

}
