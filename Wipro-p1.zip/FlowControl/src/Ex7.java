import java.util.*;
public class Ex7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		char a=sc.next().charAt(0);
		char a1=Character.toLowerCase(a);
		char a2=Character.toUpperCase(a);
		if(Character.compare(a, a1)==0)
		{
			System.out.println(a2);
		}
		else
		{
			System.out.println(a1);

		}

	}

}
