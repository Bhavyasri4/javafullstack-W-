import java.util.*;
public class Animal {
	void eat()
	{
		System.out.println("eaat");
	}
	void sleep()
	{
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
