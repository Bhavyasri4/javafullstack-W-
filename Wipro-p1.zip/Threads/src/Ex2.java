
public class Ex2 {

	
	    public static void main(String[] args) {
	        Thread thread1 = new Thread(new MyRunnable(), "Thread 1");
	        Thread thread2 = new Thread(new MyRunnable(), "Thread 2");

	        // Set thread priorities
	        thread1.setPriority(Thread.MAX_PRIORITY); // Thread 1 has highest priority
	        thread2.setPriority(Thread.MIN_PRIORITY); // Thread 2 has lowest priority

	        // Start the threads
	        thread1.start();
	        thread2.start();
	    }

	    static class MyRunnable implements Runnable {
	        public void run() {
	            for (int i = 0; i < 5; i++) {
	                System.out.println(Thread.currentThread().getName() + " is running with priority " + Thread.currentThread().getPriority());
	                try {
	                    Thread.sleep(1000);
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }
	}


