
public class Ex1 implements Runnable{
	
	    public void run() {
	        // Code to be executed in the thread
	        for (int i = 1; i <= 5; i++) {
	            System.out.println("Thread: " + Thread.currentThread().getId() + " - Count: " + i);
	            try {
	                Thread.sleep(1000);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	    }

	    public static void main(String[] args) {
	        // Creating and starting two threads
	        Thread thread1 = new Thread(new Ex1());
	        Thread thread2 = new Thread(new Ex1());
	        thread1.start();
	        thread2.start();
	    }
	}
	