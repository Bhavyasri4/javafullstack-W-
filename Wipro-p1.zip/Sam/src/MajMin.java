import java.util.Arrays;

public class MajMin {

    public static int[] majorityMinorityElements(int[] arr) {
        int n = arr.length;
        Arrays.sort(arr);
        
        // Majority element
        int majority = arr[n / 2];
        int majorityCount = countOccurrences(arr, majority);
        if (majorityCount > n / 2) {
            return new int[] { majority };
        }

        // Minority element
        int minority = arr[0];
        return new int[] { majority, minority };
    }

    private static int countOccurrences(int[] arr, int target) {
        int count = 0;
        for (int num : arr) {
            if (num == target) {
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args) {
        int[] arr = { 1, 2, 2, 3, 2, 4, 2, 5, 2 };
        int[] result = majorityMinorityElements(arr);

        System.out.println("Majority element(s): " + Arrays.toString(result));
    }
}
