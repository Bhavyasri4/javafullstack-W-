import java.util.*;
public class PINUser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String st=sc.nextLine();
		int a=sc.nextInt();
		int b=sc.nextInt();
		int small=9;
		int large=0;
		String b1="";
		String a1="";
		if(st.length()>=2)
		{
		  a1=st.substring(st.length()-2);
		 b1=a1.toUpperCase();
		}
		System.out.print("PIN:"+b1);
		while(a>0)
		{
			int n=a%10;
			if(n>large)
			{
				large=n;
			}
			a=a/10;
			
		}
		System.out.print(large);
		while(b>0)
		{
			int n1=b%10;
			if(n1<small)
			{
				small=n1;
			}
			b=b/10;
			
	}
		System.out.print(small);

}
}
