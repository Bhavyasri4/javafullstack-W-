import java.util.*;
public class Wr4 {
	public void m1(Double x)
	{
		System.out.println("Double");
	}
	public void m1(long x)
	{
		System.out.println("long");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=0;
		Wr4 w=new Wr4();
		w.m1(x);
		Long li=10L;
		w.m1(li);

	}

}
