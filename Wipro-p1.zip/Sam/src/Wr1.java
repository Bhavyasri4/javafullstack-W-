import java.util.*;
public class Wr1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=10;
		Integer y=new Integer(10);
		System.out.println(x==y);

	}

}
