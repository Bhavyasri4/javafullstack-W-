import java.util.*;
public class AvgArr {
	int median(int a[])
	{
		int le=a.length;
		if(a.length%2!=0) {
			
			int me=a[le/2];
	
		return me;
		}
		else
		{
			int a2=a[(le-1)/2]+a[le/2];
			int me=a2/2;
			return me;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter the size");
	    int si=sc.nextInt();
	    int a[]=new int[si];
	    for(int i=0;i<si;i++)
	    {
	    	a[i]=sc.nextInt();
	    }
	    AvgArr av=new AvgArr();
	    int medi=av.median(a); 
	    Arrays.sort(a);
	    int le1=a.length;
	    
	    int s1=a[1]+a[le1-2]+medi;
	    double avg=s1/3.0;
	   
	    System.out.println(s1);
	    System.out.println(avg);


	}

}
