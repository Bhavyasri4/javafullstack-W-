import java.util.*;
public class Wr3 {
	void m1(Integer il)
	{
		System.out.println("int value="+il);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Wr3 t=new Wr3();
		t.m1(10);
		

	}

}
