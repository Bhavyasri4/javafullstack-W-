/*import java.util.*;
public class SumOfPrime {
	int SumPrime(int a[])
	{
		int sum;
		return sum;
	}
	boolean isprime(int b)
	{
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out .println("Enter the size");
		int s=sc.nextInt();
		int a[]=new int[s];
		int a1[];
		int c=0;
		for(int i=0;i<s;i++)
		{
			a[i]=sc.nextInt();
		}
		
		

	}

}*/
import java.util.*;

public class SumOfPrime {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();
        
        int[] array = new int[size];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }
        
        int largest = array[0];
        for (int i = 1; i < size; i++) {
            if (array[i] > largest) {
                largest = array[i];
            }
        }
        
        int largestPrime = findLargestPrime(array);
        
        int sum = 0;
        for (int i = 0; i < size; i++) {
            if (array[i] != largestPrime && isPrime(array[i])) {
                sum += array[i];
            }
        }
        
        System.out.println("Sum of prime numbers except largest prime number: " + sum);
        
    }
    
    public static boolean isPrime(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
    
    
    public static int findLargestPrime(int[] array) {
        int largestPrime = Integer.MIN_VALUE;
        for (int num : array) {
            if (isPrime(num) && num > largestPrime) {
                largestPrime = num;
            }
        }
        return largestPrime;
    }
}

