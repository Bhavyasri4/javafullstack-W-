import java.util.*;
public class PinGen4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		        Scanner sc=new Scanner(System.in);
		        int a=sc.nextInt();
		        int b=sc.nextInt();
		        int c=sc.nextInt();
		        int d=sc.nextInt();
		        int sum=0;
		        int r=0;
		        int arr[]= {a,b,c};
		        if(d%2!=0)
		        {
		        	for(int i=0;i<3;i++)
		        	{  
		        		while(arr[i]>0) {
		        		r=arr[i]%10;
		        		if(r%2!=0)
		        		{
		        			sum=sum+r;
		        		}
		        		arr[i]=arr[i]/10;
		        		}
		        	}
		        	 System.out.println("PIN:"+sum);
				
		        }
		        else
		        {
		        	for(int i=0;i<3;i++)
		        	{ 
		        		while(arr[i]>0) {
		        		r=arr[i]%10;
		        		if(r%2==0)
		        			sum=sum+r;
		        		arr[i]=arr[i]/10;
		        		}
		        	}
		        	
		        }
		        System.out.println("PIN:"+sum);
		        
		        
			}

		}

	