/*import java.util.*;
public class RelativePrime {
	int gcd(int a,int b)
	{
		if(b==0)
			return a;
		else
			return gcd(a,a%b);
	}
	boolean relprime(int a,int b)
	{
		return gcd(a,b)==1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		RelativePrime rp=new RelativePrime();
		if(rp.relprime(a,b))
			System.out.println("relative prime");
		else
			System.out.println("not relative prime");

	}

}*/
import java.util.Scanner;

public class RelativePrime {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num1 = sc.nextInt();
        int num2 = sc.nextInt();

        if (areRelativelyPrime(num1, num2)) {
            System.out.println("are relatively prime.");
        } else {
            System.out.println("not relatively prime.");
        }
    }

    public static int gcd(int a, int b) {
        if (b == 0) {
            return a;
        } else {
            return gcd(b, a % b);
        }
    }
    public static boolean areRelativelyPrime(int a, int b) {
        return gcd(a, b) == 1;
    }
}

