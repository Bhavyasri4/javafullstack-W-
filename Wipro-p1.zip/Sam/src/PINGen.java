import java.util.*;
public class PINGen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n1 = sc.nextInt();
		int n2 = sc.nextInt();
		String name = sc.next();
		String pin = GeneratePin(n1,n2,name);
		System.out.println("Pin: "+pin);
		sc.close();
	}
	static String GeneratePin(int n1,int n2,String name) {
		String pin = "";
		int firstDigit = n1;
		while(firstDigit>=10) {
			firstDigit /= 10;
		}
		pin += firstDigit;
		
		int nextDigit = n2%10;
		pin += nextDigit;
		
		if(name.length()>=2) {
			pin += name.substring(0,2);
			
		}else {
			pin += name;
		}
		return pin;

	}

}
