import java.util.*;
public class PINgener {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		int d=sc.nextInt();
		int esum1 = 0,esum2=0,esum3=0;
		int osum1=0,osum2=0,osum3=0;
		
			String Str1 = Integer.toString(a);
			String Str2 = Integer.toString(b);
			String Str3 = Integer.toString(c);
			
	        for (int i = 0; i < Str1.length(); i++) 
	        {
	            int digit = Character.getNumericValue(Str1.charAt(i));
	            if (digit % 2 == 0) 
	                esum1 += digit;
	             else 
	                osum1 += digit;
	         }
	        for (int i = 0; i < Str2.length(); i++) 
	        {
	            int digit = Character.getNumericValue(Str2.charAt(i));
	            if (digit % 2 == 0) 
	                esum2 += digit;
	             else 
	                osum2 += digit;
	         }
	        for (int i = 0; i < Str3.length(); i++) 
	        {
	            int digit = Character.getNumericValue(Str3.charAt(i));
	            if (digit % 2 == 0) 
	                esum3 += digit;
	             else 
	                osum3 += digit;
	         }
	        if(d%2==0)
	        	System.out.println("PIN:"+esum1+esum2+esum3);
	        else
	        	System.out.println("PIN:"+osum1+osum2+osum3);
	        	
	        
	            
		

	}

}
