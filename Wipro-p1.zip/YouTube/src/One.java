import java.util.Scanner;

public class One {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a number");
		int a=s.nextInt();
		int c=0;
		while(a>0)
		{
			int rem=a%10;
			System.out.println(rem);
			for(int i=2;i<7;i++)
			{
				if(rem%i==0)
					c++;
				System.out.println(c);
				
			}
			if(c==0)
				System.out.println(a);
			a=a/10;
		}
   

	}

}
