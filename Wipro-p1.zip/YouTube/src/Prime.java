import java.util.*; 
import java.io.*;
public class Prime {

	public static int main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a number");
		int a=s.nextInt();
		int c=0;
		while(a>0)
		{
			int rem=a%10;
			for(int i=2;i<=rem;i++)
			{
				if(a%i==0)
					c++;
				if(c==1)
					System.out.println(a);
			}
			a=a/10;
		}
    return 0;
	}

}
